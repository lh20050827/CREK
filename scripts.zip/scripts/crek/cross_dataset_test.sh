#!/usr/bin/env bash

set -euo pipefail

DATASET=${1:?Usage: bash scripts/angular/cross_dataset_test.sh DATASET SEED}
SEED=${2:?Usage: bash scripts/angular/cross_dataset_test.sh DATASET SEED}

case "${DATASET}" in
    caltech101|dtd|eurosat|fgvc_aircraft|food101|oxford_flowers|oxford_pets|stanford_cars|sun397|ucf101) ;;
    *)
        echo "Unsupported cross-dataset target: ${DATASET}" >&2
        exit 2
        ;;
esac

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORKDIR="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
PYTHON="${CREK_PYTHON:-python}"
: "${CREK_DATA_ROOT:?Set CREK_DATA_ROOT to the dataset root}"
: "${CREK_TEACHER_CLIP_PATH:?Set CREK_TEACHER_CLIP_PATH to the ViT-L/14 checkpoint}"
: "${CREK_CROSS_DATASET_TEACHER_CHECKPOINT:?Set CREK_CROSS_DATASET_TEACHER_CHECKPOINT to the ImageNet domain-expert checkpoint}"
DATA_ROOT="${CREK_DATA_ROOT}"
TEACHER_CLIP="${CREK_TEACHER_CLIP_PATH}"
IMAGENET_TEACHER="${CREK_CROSS_DATASET_TEACHER_CHECKPOINT}"
OUTPUT_ROOT="${CREK_OUTPUT_ROOT:-${WORKDIR}/output/cross_dataset}"
GPU="${CUDA_VISIBLE_DEVICES:-0}"
EPOCHS="${CREK_EPOCHS:-20}"
CFG=vit_b16_c2_ep20_batch8_4+4ctx_cross_datasets
MODEL_DIR="${OUTPUT_ROOT}/${DATASET}/seed_${SEED}"

CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" "${WORKDIR}/train.py" \
    --root "${DATA_ROOT}" \
    --seed "${SEED}" \
    --trainer CREK \
    --dataset-config-file "${WORKDIR}/configs/datasets/${DATASET}.yaml" \
    --config-file "${WORKDIR}/configs/trainers/CREK/${CFG}.yaml" \
    --output-dir "${MODEL_DIR}/eval_test" \
    --eval-only \
    --model-dir "${MODEL_DIR}" \
    --load-epoch "${EPOCHS}" \
    DATASET.NUM_SHOTS 0 \
    DATASET.SUBSAMPLE_CLASSES all \
    TRAINER.MODAL cross \
    TRAINER.CREK.TEACHER_CLIP_PATH "${TEACHER_CLIP}" \
    TRAINER.CREK.CROSS_DATASET_TEACHER_CHECKPOINT "${IMAGENET_TEACHER}" \
    TEST.SPLIT test

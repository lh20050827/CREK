#!/bin/bash

set -euo pipefail

DATASET=${1:?Usage: base2new_train.sh DATASET SEED}
SEED=${2:?Usage: base2new_train.sh DATASET SEED}

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORKDIR="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
PYTHON="${CREK_PYTHON:-python}"
: "${CREK_DATA_ROOT:?Set CREK_DATA_ROOT to the dataset root}"
: "${CREK_TEACHER_CLIP_PATH:?Set CREK_TEACHER_CLIP_PATH to the ViT-L/14 checkpoint}"
: "${CREK_TEACHER_CHECKPOINT_ROOT:?Set CREK_TEACHER_CHECKPOINT_ROOT to the domain-expert checkpoint root}"
DATA_ROOT="${CREK_DATA_ROOT}"
TEACHER_CLIP="${CREK_TEACHER_CLIP_PATH}"
TEACHER_ROOT="${CREK_TEACHER_CHECKPOINT_ROOT}"
OUTPUT_ROOT="${CREK_OUTPUT_ROOT:-${WORKDIR}/output/base2new}"
GPU="${CUDA_VISIBLE_DEVICES:-0}"
CFG=vit_b16_c2_ep20_batch8_4+4ctx
EPOCHS="${CREK_EPOCHS:-20}"
WARMUP_EPOCHS="${CREK_WARMUP_EPOCHS:-30}"

if [[ "${DATASET}" == "imagenet" ]]; then
    SHOTS=16
else
    SHOTS=0
fi

DIR="${OUTPUT_ROOT}/${DATASET}/seed_${SEED}"
mkdir -p "${DIR}"

CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" "${WORKDIR}/train.py" \
    --root "${DATA_ROOT}" \
    --seed "${SEED}" \
    --trainer CREK \
    --dataset-config-file "${WORKDIR}/configs/datasets/${DATASET}.yaml" \
    --config-file "${WORKDIR}/configs/trainers/CREK/${CFG}.yaml" \
    --output-dir "${DIR}" \
    DATASET.NUM_SHOTS "${SHOTS}" \
    TRAINER.MODAL base2novel \
    TRAINER.CREK.KD_WEIGHT 1.0 \
    TRAINER.CREK.TEACHER_CLIP_PATH "${TEACHER_CLIP}" \
    TRAINER.CREK.TEACHER_CHECKPOINT_ROOT "${TEACHER_ROOT}" \
    TRAINER.CREK.ANGULAR.WARMUP_EPOCHS "${WARMUP_EPOCHS}" \
    OPTIM.MAX_EPOCH "${EPOCHS}" \
    TEST.FINAL_MODEL last_step \
    TEST.SPLIT val

CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" "${WORKDIR}/train.py" \
    --root "${DATA_ROOT}" \
    --seed "${SEED}" \
    --trainer CREK \
    --dataset-config-file "${WORKDIR}/configs/datasets/${DATASET}.yaml" \
    --config-file "${WORKDIR}/configs/trainers/CREK/${CFG}.yaml" \
    --output-dir "${DIR}/eval_novel" \
    --eval-only \
    --model-dir "${DIR}" \
    --load-epoch "${EPOCHS}" \
    DATASET.NUM_SHOTS "${SHOTS}" \
    TRAINER.MODAL base2novel \
    TRAINER.CREK.TEACHER_CLIP_PATH "${TEACHER_CLIP}" \
    TRAINER.CREK.TEACHER_CHECKPOINT_ROOT "${TEACHER_ROOT}" \
    TEST.SPLIT test

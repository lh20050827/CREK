import hashlib
import random

from dassl.utils import Registry, check_availability

DATASET_REGISTRY = Registry("DATASET")


def build_dataset(cfg):
    avai_datasets = DATASET_REGISTRY.registered_names()
    check_availability(cfg.DATASET.NAME, avai_datasets)
    if cfg.VERBOSE:
        print("Loading dataset: {}".format(cfg.DATASET.NAME))

    dataset = DATASET_REGISTRY.get(cfg.DATASET.NAME)(cfg)
    unlabeled_ratio = float(cfg.DATASET.UNLABELED_RATIO)
    if not 0.0 < unlabeled_ratio <= 1.0:
        raise ValueError("DATASET.UNLABELED_RATIO must be in (0, 1]")

    # CREK's base-to-novel training uses train_x and train_u as two loaders over
    # the same unlabeled image set. Apply one seed-fixed, label-agnostic index
    # subset to both lists while leaving class metadata and evaluation splits
    # untouched.
    use_subset = (
        cfg.TRAINER.NAME == "CREK"
        and cfg.TRAINER.MODAL == "base2novel"
        and unlabeled_ratio < 1.0
    )
    if use_subset:
        full_train_x = list(dataset.train_x)
        full_train_u = list(dataset.train_u)
        if not full_train_x:
            raise ValueError("Cannot subsample an empty CREK training split")
        if len(full_train_x) != len(full_train_u):
            raise ValueError(
                "CREK train_x and train_u must have the same length before "
                "unlabeled-data subsampling"
            )

        x_paths = [item.impath for item in full_train_x]
        u_paths = [item.impath for item in full_train_u]
        if x_paths != u_paths:
            raise ValueError(
                "CREK train_x and train_u must have identical image order "
                "before unlabeled-data subsampling"
            )

        num_selected = max(1, int(round(len(full_train_x) * unlabeled_ratio)))
        indices = list(range(len(full_train_x)))
        random.Random(int(cfg.SEED)).shuffle(indices)
        indices = sorted(indices[:num_selected])
        dataset._train_x = [full_train_x[i] for i in indices]
        dataset._train_u = [full_train_u[i] for i in indices]

        selected_paths = "\n".join(dataset.train_x[i].impath for i in range(num_selected))
        digest = hashlib.sha256(selected_paths.encode("utf-8")).hexdigest()[:12]
        print(
            "CREK unlabeled subset: "
            f"dataset={cfg.DATASET.NAME}, ratio={unlabeled_ratio:.2%}, "
            f"selected={num_selected}/{len(full_train_x)}, seed={cfg.SEED}, "
            f"digest={digest}"
        )

    return dataset

import torch
import torch.nn as nn
import torch.nn.functional as F


def _off_diagonal_mean(matrix, sample_mask=None):
    """Average ordered off-diagonal entries of a [B, N, N] matrix."""
    if sample_mask is not None:
        matrix = matrix[sample_mask]
    if matrix.shape[0] == 0:
        return matrix.sum() * 0.0

    n_views = matrix.shape[1]
    eye = torch.eye(n_views, dtype=torch.bool, device=matrix.device)
    return matrix[:, ~eye].mean()


def constrained_inter_angle(teacher, views, margin, contrast_temperature):
    """Equation (3): teacher constraint plus gated inter-view diversity.

    Args:
        teacher: [B, D]
        views: [B, N, D]
    """
    if teacher.ndim != 2 or views.ndim != 3:
        raise ValueError("Expected teacher [B,D] and views [B,N,D]")
    if teacher.shape[0] != views.shape[0] or teacher.shape[1] != views.shape[2]:
        raise ValueError("Teacher/view feature shapes are incompatible")

    batch_size, n_views, _ = views.shape
    teacher_n = F.normalize(teacher.float(), dim=-1, eps=1e-6)
    views_n = F.normalize(views.float(), dim=-1, eps=1e-6)

    # Each view's positive is the original teacher output from the same image;
    # teacher outputs from the other batch elements are negatives.
    similarities = torch.einsum("bnd,kd->bnk", views_n, teacher_n)
    positive = similarities.diagonal(dim1=0, dim2=2).transpose(0, 1)
    # Follow the effective official implementation: gamma is a fixed angular
    # boundary. A positive already inside the boundary is saturated at one;
    # an outside positive is pulled toward its matching teacher by InfoNCE.
    positive_with_margin = torch.where(
        positive >= (1.0 - margin), torch.ones_like(positive), positive
    )

    positive_mask = torch.eye(
        batch_size, dtype=similarities.dtype, device=similarities.device
    ).unsqueeze(1)
    scores = similarities * (1.0 - positive_mask)
    scores = scores + positive_with_margin.unsqueeze(-1) * positive_mask
    labels = torch.arange(batch_size, device=views.device)
    labels = labels[:, None].expand(batch_size, n_views).reshape(-1)
    constraint = F.cross_entropy(
        scores.reshape(batch_size * n_views, batch_size) / contrast_temperature,
        labels,
    ) / n_views

    # The pairwise term is activated only after all views for an image are
    # inside the teacher's angular margin, exactly as described in the paper.
    inside = (positive >= (1.0 - margin)).all(dim=1)
    pairwise = F.softplus(torch.matmul(views_n, views_n.transpose(1, 2)))
    if inside.any():
        eye = torch.eye(n_views, dtype=torch.bool, device=views.device)
        active = pairwise[inside][:, ~eye].sum()
        diversity = active / (batch_size * n_views * (n_views - 1))
    else:
        diversity = pairwise.sum() * 0.0
    return constraint + diversity


def intra_angle(teacher, views):
    """Equation (4): spread teacher-to-view offset directions."""
    teacher = teacher.float()
    views = views.float()
    offsets = teacher[:, None, :] - views
    offsets = F.normalize(offsets, dim=-1, eps=1e-6)
    pairwise = torch.matmul(offsets, offsets.transpose(1, 2)).mean(dim=0)
    pairwise = F.softplus(pairwise).unsqueeze(0)
    return _off_diagonal_mean(pairwise)


class AngularViewGenerator(nn.Module):
    """Five Angular-KD views attached to a frozen CLIP teacher feature."""

    def __init__(
        self,
        feature_dim,
        num_classes,
        text_prototypes,
        logit_scale,
        dropouts=(0.20, 0.25, 0.30, 0.35, 0.40),
        margin_init=0.20,
        contrast_temperature=0.07,
        logit_temperature=4.0,
    ):
        super().__init__()
        if len(dropouts) < 2:
            raise ValueError("Angular-KD requires at least two augmented views")
        if text_prototypes.shape != (num_classes, feature_dim):
            raise ValueError(
                "text_prototypes must have shape "
                f"[{num_classes}, {feature_dim}], got {tuple(text_prototypes.shape)}"
            )

        self.feature_dim = int(feature_dim)
        self.num_classes = int(num_classes)
        self.n_views = len(dropouts)
        self.contrast_temperature = float(contrast_temperature)
        self.logit_temperature = float(logit_temperature)
        self.register_buffer(
            "logit_scale", torch.as_tensor(logit_scale).detach().float().cpu()
        )

        self.dropouts = nn.ModuleList([nn.Dropout(float(p)) for p in dropouts])
        self.projections = nn.ModuleList(
            [nn.Linear(feature_dim, feature_dim) for _ in dropouts]
        )
        self.batch_norms = nn.ModuleList(
            [nn.BatchNorm1d(feature_dim) for _ in dropouts]
        )
        self.classifiers = nn.ModuleList(
            [nn.Linear(feature_dim, num_classes) for _ in dropouts]
        )

        # Independent orthogonal transforms give structurally distinct initial
        # paths. Classifier directions start from the frozen CLIP text space,
        # retaining class semantics while remaining learnable per view.
        prototype_init = F.normalize(
            text_prototypes.detach().float().cpu(), dim=-1
        )
        for projection, batch_norm, classifier in zip(
            self.projections, self.batch_norms, self.classifiers
        ):
            with torch.no_grad():
                # A signed permutation is exactly orthogonal, creates a
                # different path per view, and avoids five expensive dense QR
                # decompositions for ViT-L's 768-dimensional feature space.
                permutation = torch.randperm(feature_dim)
                signs = torch.empty(feature_dim).bernoulli_(0.5).mul_(2).sub_(1)
                projection.weight.zero_()
                projection.weight[
                    torch.arange(feature_dim), permutation
                ] = signs
                projection.bias.zero_()
                batch_norm.weight.fill_(1.0)
                batch_norm.bias.zero_()
                # Counter-rotate the text classifier with its feature path:
                # (x W^T) (t W^T)^T = x t^T for orthogonal W. Thus the five
                # heads are structurally different without discarding CLIP's
                # image-text class geometry at initialization.
                classifier.weight.copy_(prototype_init @ projection.weight.t())
                classifier.bias.zero_()

        margin_init = float(margin_init)
        if not 0.0 < margin_init < 1.0:
            raise ValueError("margin_init must lie strictly between zero and one")
        # The repository declares gamma learnable but immediately calls
        # .item(), so its effective and stable behavior is a fixed 0.2 margin.
        # Keeping it fixed also prevents the trivial gamma -> 1 solution.
        self.register_buffer("feature_margin", torch.tensor(margin_init))
        self.register_buffer("logit_margin", torch.tensor(margin_init))

    def forward(self, teacher_feature):
        teacher_feature = teacher_feature.detach().float()
        view_features = []
        view_logits = []
        for dropout, projection, batch_norm, classifier in zip(
            self.dropouts, self.projections, self.batch_norms, self.classifiers
        ):
            feature = batch_norm(projection(dropout(teacher_feature)))
            # A cosine classifier is the CLIP-compatible form of the paper's
            # per-view Linear(D,C) head. Its weights are independently trained.
            feature_for_cls = F.normalize(feature, dim=-1, eps=1e-6)
            weight_for_cls = F.normalize(classifier.weight, dim=-1, eps=1e-6)
            logits = (
                self.logit_scale * F.linear(feature_for_cls, weight_for_cls)
                + classifier.bias
            )
            view_features.append(feature)
            view_logits.append(logits)

        return torch.stack(view_features, dim=1), torch.stack(view_logits, dim=1)

    def angular_losses(self, teacher_feature, teacher_logits, view_features, view_logits):
        teacher_feature = teacher_feature.detach().float()
        teacher_logits = teacher_logits.detach().float()

        feature_inter = constrained_inter_angle(
            teacher_feature,
            view_features,
            self.feature_margin,
            self.contrast_temperature,
        )
        feature_intra = intra_angle(teacher_feature, view_features)

        teacher_prob = F.softmax(teacher_logits / self.logit_temperature, dim=-1)
        view_prob = F.softmax(view_logits / self.logit_temperature, dim=-1)
        logit_inter = constrained_inter_angle(
            teacher_prob,
            view_prob,
            self.logit_margin,
            self.contrast_temperature,
        )
        logit_intra = intra_angle(teacher_prob, view_prob)

        # The original method uses ground-truth CE here. CREK is unlabeled, so
        # the frozen teacher supplies the boundary target instead. Batch labels
        # are never accepted by this module.
        pseudo_label = teacher_logits.argmax(dim=-1)
        semantic = sum(
            F.cross_entropy(view_logits[:, i, :], pseudo_label)
            for i in range(self.n_views)
        )

        return {
            "feature_inter": feature_inter,
            "feature_intra": feature_intra,
            "logit_inter": logit_inter,
            "logit_intra": logit_intra,
            "semantic": semantic,
        }

    def total_augmentation_loss(self, losses, weights):
        return (
            float(weights["feature_inter"]) * losses["feature_inter"]
            + float(weights["feature_intra"]) * losses["feature_intra"]
            + float(weights["logit_inter"]) * losses["logit_inter"]
            + float(weights["logit_intra"]) * losses["logit_intra"]
            + float(weights["semantic"]) * losses["semantic"]
        )

    @staticmethod
    def ensemble_probabilities(teacher_logits, view_logits, temperatures):
        """Uniform (N+1)-way ensemble from paper Sec. 2.3."""
        output = {}
        teacher_logits = teacher_logits.detach().float()
        for temperature in temperatures:
            temperature = float(temperature)
            teacher_prob = F.softmax(teacher_logits / temperature, dim=-1)
            view_prob = F.softmax(view_logits.float() / temperature, dim=-1)
            ensemble = torch.cat([teacher_prob[:, None, :], view_prob], dim=1).mean(dim=1)
            ensemble = ensemble / ensemble.sum(dim=-1, keepdim=True).clamp_min(1e-12)
            output[temperature] = ensemble
        return output

import os.path as osp
import os
import csv
import random
import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.cuda.amp import GradScaler, autocast

from dassl.engine import TRAINER_REGISTRY, TrainerX, TrainerXU
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler

from clip import clip
from clip.simple_tokenizer import SimpleTokenizer as _Tokenizer
from tqdm import tqdm


_tokenizer = _Tokenizer()

import math
import numpy as np


def _required_file(path_value, config_key):
    """Resolve an external asset path and fail with an actionable message."""
    if not path_value:
        raise ValueError(
            f"{config_key} is not set. CREK does not bundle teacher weights; "
            "provide the external asset path in the config or command line."
        )

    path = osp.realpath(osp.expanduser(os.path.expandvars(path_value)))
    if not osp.isfile(path):
        raise FileNotFoundError(f'{config_key} does not point to a file: "{path}"')

    return path


def _required_directory(path_value, config_key):
    """Resolve a required external directory without modifying it."""
    if not path_value:
        raise ValueError(
            f"{config_key} is not set. CREK does not bundle teacher weights; "
            "provide the external checkpoint root in the config or command line."
        )

    path = osp.realpath(osp.expanduser(os.path.expandvars(path_value)))
    if not osp.isdir(path):
        raise FileNotFoundError(
            f'{config_key} does not point to a directory: "{path}"'
        )

    return path

def kd_loss(logits_student, logits_teacher, temperature, reduce=True):
    log_pred_student = F.log_softmax(logits_student / temperature, dim=1)
    pred_teacher = F.softmax(logits_teacher / temperature, dim=1)
    if reduce:
        loss_kd = F.kl_div(log_pred_student, pred_teacher, reduction="none").sum(1).mean()
    else:
        loss_kd = F.kl_div(log_pred_student, pred_teacher, reduction="none").sum(1)
    loss_kd *= temperature**2
    return loss_kd

def cc_loss(logits_student, logits_teacher, temperature, reduce=True):
    batch_size, class_num = logits_teacher.shape
    pred_student = F.softmax(logits_student / temperature, dim=1)
    pred_teacher = F.softmax(logits_teacher / temperature, dim=1)
    student_matrix = torch.mm(pred_student.transpose(1, 0), pred_student)
    teacher_matrix = torch.mm(pred_teacher.transpose(1, 0), pred_teacher)
    if reduce:
        consistency_loss = ((teacher_matrix - student_matrix) ** 2).sum() / class_num
    else:
        consistency_loss = ((teacher_matrix - student_matrix) ** 2) / class_num
    return consistency_loss


def bc_loss(logits_student, logits_teacher, temperature, reduce=True):
    batch_size, class_num = logits_teacher.shape
    pred_student = F.softmax(logits_student / temperature, dim=1)
    pred_teacher = F.softmax(logits_teacher / temperature, dim=1)
    student_matrix = torch.mm(pred_student, pred_student.transpose(1, 0))
    teacher_matrix = torch.mm(pred_teacher, pred_teacher.transpose(1, 0))
    if reduce:
        consistency_loss = ((teacher_matrix - student_matrix) ** 2).sum() / batch_size
    else:
        consistency_loss = ((teacher_matrix - student_matrix) ** 2) / batch_size
    return consistency_loss


def kd_loss_from_probs(logits_student, teacher_prob, temperature, reduce=True):
    """CREK's KD term with an already-normalized ensemble teacher target."""
    log_pred_student = F.log_softmax(logits_student / temperature, dim=1)
    teacher_prob = teacher_prob.detach()
    loss = F.kl_div(log_pred_student, teacher_prob, reduction="none").sum(1)
    if reduce:
        loss = loss.mean()
    return loss * (temperature ** 2)


def cc_loss_from_probs(logits_student, teacher_prob, temperature, reduce=True):
    _, class_num = teacher_prob.shape
    pred_student = F.softmax(logits_student / temperature, dim=1)
    teacher_prob = teacher_prob.detach()
    student_matrix = torch.mm(pred_student.transpose(1, 0), pred_student)
    teacher_matrix = torch.mm(teacher_prob.transpose(1, 0), teacher_prob)
    difference = (teacher_matrix - student_matrix) ** 2 / class_num
    return difference.sum() if reduce else difference


def bc_loss_from_probs(logits_student, teacher_prob, temperature, reduce=True):
    batch_size, _ = teacher_prob.shape
    pred_student = F.softmax(logits_student / temperature, dim=1)
    teacher_prob = teacher_prob.detach()
    student_matrix = torch.mm(pred_student, pred_student.transpose(1, 0))
    teacher_matrix = torch.mm(teacher_prob, teacher_prob.transpose(1, 0))
    difference = (teacher_matrix - student_matrix) ** 2 / batch_size
    return difference.sum() if reduce else difference

def load_clip_to_cpu_teacher(cfg, zero_shot_model=False):
    backbone_name = cfg.TRAINER.CREK.TEACHER_NAME
    model_path = _required_file(
        cfg.TRAINER.CREK.TEACHER_CLIP_PATH,
        "TRAINER.CREK.TEACHER_CLIP_PATH",
    )
    
    print(f"CLIP Teacher name is {backbone_name}")
    
    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    if cfg.TRAINER.CREK.ZERO_SHOT_TEACHER:
        # Reconstruct the untouched OpenAI CLIP architecture: no shallow or
        # deep visual/text prompt parameters are inserted into the teacher.
        design_details = {
            "trainer": "CoOp",
            "vision_depth": 0,
            "language_depth": 0,
            "vision_ctx": 0,
            "language_ctx": 0,
        }
    else:
        # Build the externally prompt-tuned domain-expert architecture.
        design_details = {
            "trainer": "IVLP",
            "vision_depth": 9,
            "language_depth": 9,
            "vision_ctx": 4,
            "language_ctx": 4,
        }
    
    model = clip.build_model(state_dict or model.state_dict(), design_details)

    return model

def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")
    design_details = {"trainer": 'IVLP',
                      "vision_depth": 0,
                      "language_depth": 0, "vision_ctx": 0,
                      "language_ctx": 0}
    model = clip.build_model(state_dict or model.state_dict(), design_details)

    return model


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        x = prompts + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x).type(self.dtype)

        # x.shape = [batch_size, n_ctx, transformer.width]
        # take features from the eot embedding (eot_token is the highest number in each sequence)
        x = x[torch.arange(x.shape[0]), tokenized_prompts.argmax(dim=-1)] @ self.text_projection

        return x

class VLPromptLearner_tea(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        n_cls = len(classnames)
        # Make sure Language depth >= 1
        assert cfg.TRAINER.CREK.PROMPT_DEPTH_TEXT >= 1, "In Independent VL prompting, Language prompt depth should be >=1" \
                                                        "\nPlease use VPT trainer if you want to learn only vision " \
                                                        "branch"
        n_ctx = cfg.TRAINER.CREK.N_CTX_TEXT
        ctx_init = cfg.TRAINER.CREK.CTX_INIT
        dtype = clip_model.dtype
        ctx_dim = clip_model.ln_final.weight.shape[0]
        clip_imsize = clip_model.visual.input_resolution
        cfg_imsize = cfg.INPUT.SIZE[0]
        assert cfg_imsize == clip_imsize, f"cfg_imsize ({cfg_imsize}) must equal to clip_imsize ({clip_imsize})"
        
        self.trainer_name = cfg.TRAINER.NAME
        self.train_modal = cfg.TRAINER.MODAL
        
        if ctx_init and n_ctx <= 4:
            # use given words to initialize context vectors
            ctx_init = ctx_init.replace("_", " ")
            n_ctx = n_ctx
            prompt = clip.tokenize(ctx_init)
            with torch.no_grad():
                embedding = clip_model.token_embedding(prompt).type(dtype)
            ctx_vectors = embedding[0, 1: 1 + n_ctx, :]
            prompt_prefix = ctx_init
        else:
            # random initialization
            ctx_vectors = torch.empty(n_ctx, ctx_dim, dtype=dtype)
            nn.init.normal_(ctx_vectors, std=0.02)
            prompt_prefix = " ".join(["X"] * n_ctx)
        print(f"Independent V-L design")
        print(f'Initial text context: "{prompt_prefix}"')
        print(f"Number of context words (tokens) for Language prompting: {n_ctx}")
        print(f"Number of context words (tokens) for Vision prompting: {cfg.TRAINER.CREK.N_CTX_VISION}")
        self.ctx = nn.Parameter(ctx_vectors)

        classnames = [name.replace("_", " ") for name in classnames]
        prompts = [prompt_prefix + " " + name + "." for name in classnames]
        tokenized_prompts = torch.cat([clip.tokenize(p) for p in prompts])  # (n_cls, n_tkn)
        
        print(f'classnames size is {len(classnames)}')

        with torch.no_grad():
            embedding = clip_model.token_embedding(tokenized_prompts).type(dtype)
        
        self.n_cls = n_cls
        self.n_ctx = n_ctx
        self.tokenized_prompts = tokenized_prompts  # torch.Tensor
        # self.name_lens = name_lens

        if self.train_modal == "base2novel":
            self.register_buffer("token_prefix", embedding[:math.ceil(self.n_cls / 2), :1, :])  # SOS
            self.register_buffer("token_suffix", embedding[:math.ceil(self.n_cls / 2), 1 + n_ctx:, :])  # CLS, EOS

            self.register_buffer("token_prefix2", embedding[math.ceil(self.n_cls / 2):, :1, :])  # SOS
            self.register_buffer("token_suffix2", embedding[math.ceil(self.n_cls / 2):, 1 + n_ctx:, :])  # CLS, EOS
            
        elif self.train_modal == "cross":
            self.register_buffer("token_prefix", embedding[:, :1, :])  # SOS
            self.register_buffer("token_suffix", embedding[:, 1 + n_ctx:, :])  # CLS, EOS
            
            self.register_buffer("token_prefix2", embedding[:, :1, :])  # SOS
            self.register_buffer("token_suffix2", embedding[:, 1 + n_ctx:, :])  # CLS, EOS

    def construct_prompts(self, ctx, prefix, suffix, label=None):
        # dim0 is either batch_size (during training) or n_cls (during testing)
        # ctx: context tokens, with shape of (dim0, n_ctx, ctx_dim)
        # prefix: the sos token, with shape of (n_cls, 1, ctx_dim)
        # suffix: remaining tokens, with shape of (n_cls, *, ctx_dim)

        # print(f'label is {label}')
        # if label is not None:
        #     prefix = prefix[label]
        #     suffix = suffix[label]

        prompts = torch.cat(
            [
                prefix,  # (dim0, 1, dim)
                ctx,  # (dim0, n_ctx, dim)
                suffix,  # (dim0, *, dim)
            ],
            dim=1,
        )

        return prompts

    def forward(self):
        ctx = self.ctx
        if ctx.dim() == 2:
            ctx = ctx.unsqueeze(0).expand(self.n_cls, -1, -1)
        # print(f'ctx size is {ctx.size()}')

        prefix = self.token_prefix
        # print(f'prefix size is {prefix.size()}')
        
        suffix = self.token_suffix
        # print(f'suffix size is {suffix.size()}')

        if self.trainer_name == "CREK" and self.train_modal == "base2novel":
            # print(f'n_cls is {self.n_cls}')
            prefix = torch.cat([prefix, self.token_prefix2], dim=0)
            suffix = torch.cat([suffix, self.token_suffix2], dim=0)

        prompts = self.construct_prompts(ctx, prefix, suffix)

        return prompts

class VLPromptLearner(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        n_cls = len(classnames)
        self.n_cls = n_cls
        # Make sure Language depth >= 1
        assert cfg.TRAINER.IVLP.PROMPT_DEPTH_TEXT >= 1, "In Independent VL prompting, Language prompt depth should be >=1" \
                                                        "\nPlease use VPT trainer if you want to learn only vision " \
                                                        "branch  "
        # n_ctx = cfg.TRAINER.IVLP.N_CTX_TEXT
        n_ctx = 4
        ctx_init = cfg.TRAINER.IVLP.CTX_INIT
        dtype = clip_model.dtype
        ctx_dim = clip_model.ln_final.weight.shape[0]
        vis_dim = clip_model.visual.output_dim
        clip_imsize = clip_model.visual.input_resolution
        cfg_imsize = cfg.INPUT.SIZE[0]
        assert cfg_imsize == clip_imsize, f"cfg_imsize ({cfg_imsize}) must equal to clip_imsize ({clip_imsize})"
        
        self.trainer_name = cfg.TRAINER.NAME
        self.train_modal = cfg.TRAINER.MODAL

        ctx_vectors = torch.empty(n_cls, n_ctx, ctx_dim, dtype=dtype)
        # ctx_vectors = torch.empty(n_ctx, ctx_dim, dtype=dtype)
        nn.init.normal_(ctx_vectors, std=0.02)
        prompt_prefix = " ".join(["X"] * n_ctx)
        
        print(f"Independent V-L design")
        print(f'Initial text context: "{prompt_prefix}"')
        print(f"Number of context words (tokens) for Language prompting: {n_ctx}")
        print(f"Number of context words (tokens) for Vision prompting: {cfg.TRAINER.IVLP.N_CTX_VISION}")
        
        self.ctx = nn.Parameter(ctx_vectors)

        classnames = [name.replace("_", " ") for name in classnames]
        name_lens = [len(_tokenizer.encode(name)) for name in classnames]
        prompts = [prompt_prefix + " " + name + "." for name in classnames]

        tokenized_prompts = torch.cat([clip.tokenize(p) for p in prompts])  # (n_cls, n_tkn)
        with torch.no_grad():
            embedding = clip_model.token_embedding(tokenized_prompts).type(dtype)

        # These token vectors will be saved when in save_model(),
        # but they should be ignored in load_model() as we want to use
        # those computed using the current class names
        if self.train_modal == "base2novel":
            self.register_buffer("token_prefix", embedding[:math.ceil(self.n_cls / 2), :1, :])  # SOS
            self.register_buffer("token_suffix", embedding[:math.ceil(self.n_cls / 2), 1 + n_ctx:, :])  # CLS, EOS

            self.register_buffer("token_prefix2", embedding[math.ceil(self.n_cls / 2):, :1, :])  # SOS
            self.register_buffer("token_suffix2", embedding[math.ceil(self.n_cls / 2):, 1 + n_ctx:, :])  # CLS, EOS
            
        elif self.train_modal == "cross":
            self.register_buffer("token_prefix", embedding[:, :1, :])  # SOS
            self.register_buffer("token_suffix", embedding[:, 1 + n_ctx:, :])  # CLS, EOS
            
            self.register_buffer("token_prefix2", embedding[:, :1, :])  # SOS
            self.register_buffer("token_suffix2", embedding[:, 1 + n_ctx:, :])  # CLS, EOS

        self.n_cls = n_cls
        self.n_ctx = n_ctx
        self.tokenized_prompts = tokenized_prompts  # torch.Tensor
        self.name_lens = name_lens

    def construct_prompts(self, ctx, prefix, suffix):
        # dim0 is either batch_size (during training) or n_cls (during testing)
        # ctx: context tokens, with shape of (dim0, n_ctx, ctx_dim)
        # prefix: the sos token, with shape of (n_cls, 1, ctx_dim)
        # suffix: remaining tokens, with shape of (n_cls, *, ctx_dim
        
        prompts = torch.cat(
            [
                prefix,  # (dim0, 1, dim)
                ctx,  # (dim0, n_ctx, dim)
                suffix,  # (dim0, *, dim)
            ],
            dim=1,
        )

        return prompts

    def forward(self):
        ctx = self.ctx
        if ctx.dim() == 2:
            ctx = ctx.unsqueeze(0).expand(self.n_cls, -1, -1)

        prefix = self.token_prefix
        suffix = self.token_suffix
        
        if self.trainer_name == "CREK" and self.train_modal == "base2novel":
            # print(f'n_cls is {self.n_cls}')
            prefix = torch.cat([prefix, self.token_prefix2], dim=0)
            suffix = torch.cat([suffix, self.token_suffix2], dim=0)
        
        prompts = self.construct_prompts(ctx, prefix, suffix)

        return prompts


class CustomCLIP(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        self.prompt_learner = VLPromptLearner(cfg, classnames, clip_model)
        self.tokenized_prompts = self.prompt_learner.tokenized_prompts
        self.image_encoder = clip_model.visual
        self.text_encoder = TextEncoder(clip_model)
        self.logit_scale = clip_model.logit_scale
        self.dtype = clip_model.dtype
        self.n_cls = len(classnames)

    def forward(self, image, label):
        tokenized_prompts = self.tokenized_prompts
        logit_scale = self.logit_scale.exp()



        prompts = self.prompt_learner().half()
        text_features = self.text_encoder(prompts, tokenized_prompts)
        image_features = self.image_encoder(image.type(self.dtype))

        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)
        # logits = logit_scale * image_features @ text_features.t()

        return logit_scale, image_features, text_features
    
class CustomCLIP_teacher(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        self.prompt_learner = VLPromptLearner_tea(cfg, classnames, clip_model)
        self.tokenized_prompts = self.prompt_learner.tokenized_prompts
        self.image_encoder = clip_model.visual
        self.text_encoder = TextEncoder(clip_model).cuda()
        self.logit_scale = clip_model.logit_scale
        self.dtype = clip_model.dtype
        self.n_base_cls = math.ceil(len(classnames) / 2)

    def encode_text(self):
        prompts = self.prompt_learner()
        tokenized_prompts = self.tokenized_prompts
        text_features = self.text_encoder(prompts.cuda(), tokenized_prompts.cuda())
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)
        return text_features

    def forward(self, image=None, label=None, return_features=False, text_features=None):
        if text_features is None:
            text_features = self.encode_text()
        logit_scale = self.logit_scale.exp()
        image_features = self.image_encoder(image.type(self.dtype))
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        logits = logit_scale * image_features @ text_features.to(
            dtype=image_features.dtype
        ).t()

        if return_features:
            return logits, image_features, text_features, logit_scale
        return logits


class ZeroShotCLIP_teacher(nn.Module):
    """Frozen pretrained CLIP teacher with a fixed natural-language prompt."""

    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        self.image_encoder = clip_model.visual
        self.text_encoder = TextEncoder(clip_model)
        self.logit_scale = clip_model.logit_scale
        self.dtype = clip_model.dtype

        template = cfg.TRAINER.CREK.ZERO_SHOT_TEMPLATE
        if template.count("{}") != 1:
            raise ValueError(
                "TRAINER.CREK.ZERO_SHOT_TEMPLATE must contain exactly one '{}'"
            )
        prompts = [
            template.format(name.replace("_", " ")) for name in classnames
        ]
        tokenized_prompts = torch.cat([clip.tokenize(p) for p in prompts])
        with torch.no_grad():
            prompt_embeddings = clip_model.token_embedding(
                tokenized_prompts
            ).type(self.dtype)

        self.register_buffer("tokenized_prompts", tokenized_prompts)
        self.register_buffer("prompt_embeddings", prompt_embeddings)

    def encode_text(self):
        text_features = self.text_encoder(
            self.prompt_embeddings, self.tokenized_prompts
        )
        return text_features / text_features.norm(dim=-1, keepdim=True)

    def forward(
        self, image=None, label=None, return_features=False, text_features=None
    ):
        if text_features is None:
            text_features = self.encode_text()
        logit_scale = self.logit_scale.exp()
        image_features = self.image_encoder(image.type(self.dtype))
        image_features = image_features / image_features.norm(
            dim=-1, keepdim=True
        )
        logits = logit_scale * image_features @ text_features.to(
            dtype=image_features.dtype
        ).t()

        if return_features:
            return logits, image_features, text_features, logit_scale
        return logits


@TRAINER_REGISTRY.register()
class CREK(TrainerXU):
    def check_cfg(self, cfg):
        assert cfg.TRAINER.IVLP.PREC in ["fp16", "fp32", "amp"]

    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames
        self.n_cls = len(classnames)

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)
        clip_model_teacher = load_clip_to_cpu_teacher(cfg)

        if cfg.TRAINER.IVLP.PREC == "fp32" or cfg.TRAINER.IVLP.PREC == "amp":
            # CLIP's default precision is fp16
            clip_model.float()

        print("Building custom CLIP")
        self.model = CustomCLIP(cfg, classnames, clip_model)
        zero_shot_teacher = bool(cfg.TRAINER.CREK.ZERO_SHOT_TEACHER)
        if zero_shot_teacher:
            self.model_teacher = ZeroShotCLIP_teacher(
                cfg, classnames, clip_model_teacher
            )
            model_path = None
        else:
            self.model_teacher = CustomCLIP_teacher(
                cfg, classnames, clip_model_teacher
            )

            if cfg.TRAINER.MODAL == "base2novel":
                checkpoint_root = _required_directory(
                    cfg.TRAINER.CREK.TEACHER_CHECKPOINT_ROOT,
                    "TRAINER.CREK.TEACHER_CHECKPOINT_ROOT",
                )
                model_path = osp.join(
                    checkpoint_root,
                    str(cfg.DATASET.NAME),
                    "VLPromptLearner",
                    "model-best.pth.tar",
                )
                model_path = _required_file(
                    model_path,
                    "CREK base-to-new teacher checkpoint",
                )
            elif cfg.TRAINER.MODAL == "cross":
                model_path = _required_file(
                    cfg.TRAINER.CREK.CROSS_DATASET_TEACHER_CHECKPOINT,
                    "TRAINER.CREK.CROSS_DATASET_TEACHER_CHECKPOINT",
                )
            else:
                raise ValueError(
                    f'Unsupported TRAINER.MODAL="{cfg.TRAINER.MODAL}"; '
                    'expected "base2novel" or "cross".'
                )

        print("Turning off gradients in both the image and the text encoder")
        name_to_update = "prompt_learner"
        
        self.train_modal = cfg.TRAINER.MODAL
        
        if zero_shot_teacher:
            print(
                "Using frozen zero-shot CLIP teacher; no downstream teacher "
                "checkpoint is loaded"
            )
        else:
            checkpoint = load_checkpoint(model_path)
            state_dict = checkpoint["state_dict"]

            if "prompt_learner.token_prefix" in state_dict:
                del state_dict["prompt_learner.token_prefix"]
            if "prompt_learner.token_prefix2" in state_dict:
                del state_dict["prompt_learner.token_prefix2"]

            if "prompt_learner.token_suffix" in state_dict:
                del state_dict["prompt_learner.token_suffix"]
            if "prompt_learner.token_suffix2" in state_dict:
                del state_dict["prompt_learner.token_suffix2"]

            self.model_teacher.load_state_dict(state_dict, strict=False)
        self.model_teacher.to(self.device)
        self.model_teacher.eval()
        for param in self.model_teacher.parameters():
            param.requires_grad_(False)

        for name, param in self.model.named_parameters():
            if name_to_update not in name:
                # Make sure that VPT prompts are updated
                if "VPT" in name:
                    param.requires_grad_(True)
                else:
                    param.requires_grad_(False)

        # Double check
        enabled = set()
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                enabled.add(name)
        print(f"Parameters to be updated: {enabled}")

        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model, cfg.MODEL.INIT_WEIGHTS)

        self.model.to(self.device)
        # NOTE: only give prompt_learner to the optimizer
        self.optim = build_optimizer(self.model, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model("VLPromptLearner", self.model, self.optim, self.sched)

        angular_cfg = cfg.TRAINER.CREK.ANGULAR
        if not angular_cfg.ENABLED:
            raise ValueError("This trainer variant requires CREK.ANGULAR.ENABLED=True")
        if angular_cfg.N_VIEWS != len(angular_cfg.DROPOUTS):
            raise ValueError("ANGULAR.N_VIEWS must match the length of ANGULAR.DROPOUTS")

        with torch.no_grad():
            teacher_text = self.model_teacher.encode_text().float()
            teacher_logit_scale = self.model_teacher.logit_scale.exp().float()
        self.teacher_text_features = teacher_text.detach()
        self.angular_views = AngularViewGenerator(
            feature_dim=teacher_text.shape[1],
            num_classes=self.n_cls,
            text_prototypes=teacher_text,
            logit_scale=teacher_logit_scale,
            dropouts=tuple(angular_cfg.DROPOUTS),
            margin_init=angular_cfg.MARGIN_INIT,
            contrast_temperature=angular_cfg.CONTRAST_T,
            logit_temperature=angular_cfg.LOGIT_T,
        ).to(self.device)
        self.angular_optim = torch.optim.SGD(
            self.angular_views.parameters(),
            lr=angular_cfg.MAIN_LR,
            momentum=angular_cfg.MOMENTUM,
            weight_decay=angular_cfg.WEIGHT_DECAY,
        )
        self.angular_sched = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.angular_optim,
            T_max=max(1, cfg.OPTIM.MAX_EPOCH),
        )
        self.register_model(
            "AngularViews",
            self.angular_views,
            self.angular_optim,
            self.angular_sched,
        )

        self.angular_weights = {
            "feature_inter": angular_cfg.FEATURE_INTER_WEIGHT,
            "feature_intra": angular_cfg.FEATURE_INTRA_WEIGHT,
            "logit_inter": angular_cfg.LOGIT_INTER_WEIGHT,
            "logit_intra": angular_cfg.LOGIT_INTRA_WEIGHT,
            "semantic": angular_cfg.SEMANTIC_WEIGHT,
        }
        self.distill_temperatures = (1.0, 3.0, 5.0, 2.0, 6.0)

        self.scaler = GradScaler() if cfg.TRAINER.IVLP.PREC == "amp" else None

        # Note that multi-gpu training could be slow because CLIP's size is
        # big, which slows down the copy operation in DataParallel
        # device_count = torch.cuda.device_count()
        # if device_count > 1:
        #     print(f"Multiple GPUs detected (n_gpus={device_count}), use all of them!")
        #     self.model = nn.DataParallel(self.model)
        
        self.temperature = 1.0
        self.kd_loss_weight = 1.0

    def _angular_objective(self, teacher_feature, teacher_logits):
        view_features, view_logits = self.angular_views(teacher_feature)
        components = self.angular_views.angular_losses(
            teacher_feature,
            teacher_logits,
            view_features,
            view_logits,
        )
        total = self.angular_views.total_augmentation_loss(
            components, self.angular_weights
        )
        return total, components, view_features, view_logits

    def before_train(self):
        """Run the official 30-epoch head-only stage before CREK training."""
        super().before_train()
        if self.start_epoch > 0:
            return

        warmup_path = osp.join(self.output_dir, "angular_warmup.pth.tar")
        warmup_checkpoint = None
        if osp.isfile(warmup_path):
            warmup_checkpoint = torch.load(warmup_path, map_location=self.device)
        self._warmup_angular_views(warmup_path, warmup_checkpoint)

        # Head warm-up must not perturb CREK's seed-dependent prompt training
        # trajectory through consumed sampler/dropout random numbers.
        seed = int(self.cfg.SEED)
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    def _warmup_angular_views(self, warmup_path, checkpoint=None):
        angular_cfg = self.cfg.TRAINER.CREK.ANGULAR
        warmup_epochs = int(angular_cfg.WARMUP_EPOCHS)
        if warmup_epochs <= 0:
            print("Angular-KD head warm-up disabled by configuration")
            return

        warmup_optim = torch.optim.SGD(
            self.angular_views.parameters(),
            lr=angular_cfg.WARMUP_LR,
            momentum=angular_cfg.MOMENTUM,
            weight_decay=angular_cfg.WEIGHT_DECAY,
        )
        milestones = sorted(
            set(
                max(1, int(round(warmup_epochs * ratio)))
                for ratio in (1.0 / 3.0, 2.0 / 3.0)
            )
        )
        warmup_sched = torch.optim.lr_scheduler.MultiStepLR(
            warmup_optim, milestones=milestones, gamma=0.1
        )

        start_epoch = 0
        if checkpoint is not None:
            self.angular_views.load_state_dict(checkpoint["state_dict"], strict=True)
            start_epoch = int(checkpoint.get("epoch", 0))
            if start_epoch >= warmup_epochs:
                print(
                    f"Loaded completed Angular-KD head warm-up ({start_epoch} epochs) "
                    f"from {warmup_path}"
                )
                return
            if checkpoint.get("optimizer") is not None:
                warmup_optim.load_state_dict(checkpoint["optimizer"])
            if checkpoint.get("scheduler") is not None:
                warmup_sched.load_state_dict(checkpoint["scheduler"])
            print(f"Resuming Angular-KD head warm-up at epoch {start_epoch + 1}")

        # Reuse the exact CREK dataset wrapper/transforms with the official
        # Angular-KD warm-up batch size. Eight workers are retained, and every
        # epoch receives a fresh random crop/flip rather than a cached feature.
        warmup_loader = torch.utils.data.DataLoader(
            self.train_loader_x.dataset,
            batch_size=int(angular_cfg.WARMUP_BATCH_SIZE),
            shuffle=True,
            num_workers=int(self.cfg.DATALOADER.NUM_WORKERS),
            drop_last=True,
            pin_memory=(torch.cuda.is_available() and self.cfg.USE_CUDA),
        )
        if len(warmup_loader) == 0:
            raise RuntimeError("Angular-KD warm-up loader is empty")

        print(
            f"Angular-KD head-only warm-up: epochs={warmup_epochs}, "
            f"batch={angular_cfg.WARMUP_BATCH_SIZE}, "
            f"workers={self.cfg.DATALOADER.NUM_WORKERS}, labels=unused"
        )
        self.model.eval()
        self.model_teacher.eval()
        self.angular_views.train()
        for epoch in range(start_epoch, warmup_epochs):
            running = 0.0
            steps = 0
            for batch in warmup_loader:
                image = batch["img"].to(self.device, non_blocking=True)
                with torch.no_grad():
                    teacher_logits, teacher_feature, _, _ = self.model_teacher(
                        image,
                        return_features=True,
                        text_features=self.teacher_text_features,
                    )
                loss, _, _, _ = self._angular_objective(
                    teacher_feature, teacher_logits
                )
                if not torch.isfinite(loss):
                    raise FloatingPointError("Non-finite Angular-KD warm-up loss")
                warmup_optim.zero_grad()
                loss.backward()
                warmup_optim.step()
                running += float(loss.detach())
                steps += 1
            warmup_sched.step()
            print(
                f"Angular warm-up [{epoch + 1:02d}/{warmup_epochs}] "
                f"loss={running / steps:.6f} lr={warmup_optim.param_groups[0]['lr']:.3e}"
            )
            os.makedirs(self.output_dir, exist_ok=True)
            state = {
                "state_dict": self.angular_views.state_dict(),
                "epoch": epoch + 1,
                "optimizer": warmup_optim.state_dict(),
                "scheduler": warmup_sched.state_dict(),
                "uses_ground_truth_labels": False,
                "images_per_epoch": len(warmup_loader)
                * int(angular_cfg.WARMUP_BATCH_SIZE),
            }
            temporary_path = warmup_path + ".tmp"
            torch.save(state, temporary_path)
            os.replace(temporary_path, warmup_path)
        print(f"Saved Angular-KD head warm-up to {warmup_path}")

    def _forward_backward_original(self, batch_x, batch_u):
        # image, label = self.parse_batch_train(batch)
        image_weak, image_strong, label = self.parse_batch_train(batch_x, batch_u)
        

        model = self.model
        optim = self.optim
        scaler = self.scaler

        prec = self.cfg.TRAINER.IVLP.PREC
        if prec == "amp":
            with autocast():
                loss = model(image_weak, label)
            optim.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optim)
            scaler.update()
        else:
            logit_scale, img_ft_weak, text_features = model(image_weak, label)

            logits_student_weak = logit_scale * img_ft_weak @ text_features.t()
            
            logit_scale, img_ft_strong, text_features = model(image_strong, label)
            logits_student_strong = logit_scale * img_ft_strong @ text_features.t()
            
            with torch.no_grad():
                logits_teacher_weak = self.model_teacher(image_weak, label)
                logits_teacher_strong = self.model_teacher(image_strong, label)
            
            batch_size, class_num = logits_student_strong.shape
            
            pred_teacher_weak = F.softmax(logits_teacher_weak.detach(), dim=1)
            confidence, pseudo_labels = pred_teacher_weak.max(dim=1)
            confidence = confidence.detach()
            conf_thresh = np.percentile(
                confidence.cpu().numpy().flatten(), 50
            )
            mask = confidence.le(conf_thresh).bool()
            
            class_confidence = torch.sum(pred_teacher_weak, dim=0)
            class_confidence = class_confidence.detach()
            class_confidence_thresh = np.percentile(
                class_confidence.cpu().numpy().flatten(), 50
            )
            class_conf_mask = class_confidence.le(class_confidence_thresh).bool()

            loss_kd_weak = self.kd_loss_weight * ((kd_loss(
            logits_student_weak,
            logits_teacher_weak,
            self.temperature,
            # reduce=False
            ) * mask).mean()) + self.kd_loss_weight * ((kd_loss(
                logits_student_weak,
                logits_teacher_weak,
                3.0,
                # reduce=False
            ) * mask).mean()) + self.kd_loss_weight * ((kd_loss(
                logits_student_weak,
                logits_teacher_weak,
                5.0,
                # reduce=False
            ) * mask).mean()) + self.kd_loss_weight * ((kd_loss(
                logits_student_weak,
                logits_teacher_weak,
                2.0,
                # reduce=False
            ) * mask).mean()) + self.kd_loss_weight * ((kd_loss(
                logits_student_weak,
                logits_teacher_weak,
                6.0,
                # reduce=False
            ) * mask).mean())

            loss_kd_strong = self.kd_loss_weight * kd_loss(
                logits_student_strong,
                logits_teacher_strong,
                self.temperature,
            ) + self.kd_loss_weight * kd_loss(
                logits_student_strong,
                logits_teacher_strong,
                3.0,
            ) + self.kd_loss_weight * kd_loss(
                logits_student_strong,
                logits_teacher_strong,
                5.0,
            ) + self.kd_loss_weight * kd_loss(
                logits_student_weak,
                logits_teacher_weak,
                2.0,
            ) + self.kd_loss_weight * kd_loss(
                logits_student_weak,
                logits_teacher_weak,
                6.0,
            )

            loss_cc_weak = self.kd_loss_weight * ((cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                self.temperature,
                # reduce=False
            ) * class_conf_mask).mean()) + self.kd_loss_weight * ((cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                3.0,
            ) * class_conf_mask).mean()) + self.kd_loss_weight * ((cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                5.0,
            ) * class_conf_mask).mean()) + self.kd_loss_weight * ((cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                2.0,
            ) * class_conf_mask).mean()) + self.kd_loss_weight * ((cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                6.0,
            ) * class_conf_mask).mean())
            
            loss_cc_strong = self.kd_loss_weight * cc_loss(
                logits_student_strong,
                logits_teacher_strong,
                self.temperature,
            ) + self.kd_loss_weight * cc_loss(
                logits_student_strong,
                logits_teacher_strong,
                3.0,
            ) + self.kd_loss_weight * cc_loss(
                logits_student_strong,
                logits_teacher_strong,
                5.0,
            ) + self.kd_loss_weight * cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                2.0,
            ) + self.kd_loss_weight * cc_loss(
                logits_student_weak,
                logits_teacher_weak,
                6.0,
            )

            loss_bc_weak = self.kd_loss_weight * ((bc_loss(
                logits_student_weak,
                logits_teacher_weak,
                self.temperature,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_weak,
                logits_teacher_weak,
                3.0,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_weak,
                logits_teacher_weak,
                5.0,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_weak,
                logits_teacher_weak,
                2.0,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_weak,
                logits_teacher_weak,
                6.0,
            ) * mask).mean())
            
            loss_bc_strong = self.kd_loss_weight * ((bc_loss(
                logits_student_strong,
                logits_teacher_strong,
                self.temperature,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_strong,
                logits_teacher_strong,
                3.0,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_strong,
                logits_teacher_strong,
                5.0,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_strong,
                logits_teacher_strong,
                2.0,
            ) * mask).mean()) + self.kd_loss_weight * ((bc_loss(
                logits_student_strong,
                logits_teacher_strong,
                6.0,
            ) * mask).mean())

            
            # losses_dict = {
            # "loss_kd": loss_kd_weak + loss_kd_strong,
            # "loss_cc": loss_cc_weak + loss_cc_strong,
            # "loss_bc": loss_bc_weak + loss_bc_strong
            # }
            
            losses_dict = {
            "loss_kd": loss_kd_weak,
            "loss_cc": loss_cc_weak,
            "loss_bc": loss_bc_weak
            }
            
            
            loss = sum([l.mean() for l in losses_dict.values()])
            
            optim.zero_grad()
            loss.backward()
            optim.step()
            
            # def closure():
            #     optim.zero_grad()
            #     loss = L_ukd
            #     loss.backward(retain_graph=True)
            #     return loss

            # loss = optim.step(closure)

        loss_summary = {"loss": loss.item()}

        # Record the three distillation terms exactly as they participate in
        # the optimization above. Values are averaged over all batches in an
        # epoch and written once per epoch for downstream curve plotting.
        if prec != "amp":
            component_values = {
                "loss_kd": loss_kd_weak.item(),
                "loss_cc": loss_cc_weak.item(),
                "loss_bc": loss_bc_weak.item(),
            }
            loss_summary.update(component_values)

            if self.batch_idx == 0:
                self._epoch_loss_sums = {
                    "loss_kd": 0.0,
                    "loss_cc": 0.0,
                    "loss_bc": 0.0,
                }
                self._epoch_loss_count = 0

            for name, value in component_values.items():
                self._epoch_loss_sums[name] += value
            self._epoch_loss_count += 1

            if (self.batch_idx + 1) == self.num_batches:
                os.makedirs(self.cfg.OUTPUT_DIR, exist_ok=True)
                csv_path = osp.join(self.cfg.OUTPUT_DIR, "loss_trends.csv")
                file_mode = "w" if self.epoch == 0 else "a"
                fieldnames = [
                    "epoch",
                    "loss_kd",
                    "loss_cc",
                    "loss_bc",
                ]
                row = {
                    "epoch": self.epoch + 1,
                    "loss_kd": self._epoch_loss_sums["loss_kd"] / self._epoch_loss_count,
                    "loss_cc": self._epoch_loss_sums["loss_cc"] / self._epoch_loss_count,
                    "loss_bc": self._epoch_loss_sums["loss_bc"] / self._epoch_loss_count,
                }
                with open(csv_path, file_mode, newline="") as csv_file:
                    writer = csv.DictWriter(
                        csv_file,
                        fieldnames=fieldnames,
                        lineterminator="\n",
                    )
                    if file_mode == "w":
                        writer.writeheader()
                    writer.writerow(row)
                print(f"Epoch loss averages saved to {csv_path}: {row}")

        if (self.batch_idx + 1) == self.num_batches:
            self.update_lr()

        return loss_summary

    def forward_backward(self, batch_x, batch_u):
        """CREK's three losses driven by a full Angular-KD teacher ensemble."""
        image_weak, _image_strong, _label_unused = self.parse_batch_train(
            batch_x, batch_u
        )

        logit_scale, image_feature, text_features = self.model(
            image_weak, None
        )
        logits_student = logit_scale * image_feature @ text_features.t()

        with torch.no_grad():
            (
                logits_teacher,
                feature_teacher,
                _,
                _,
            ) = self.model_teacher(
                image_weak,
                return_features=True,
                text_features=self.teacher_text_features,
            )

        angular_loss, angular_components, _, view_logits = self._angular_objective(
            feature_teacher, logits_teacher
        )
        ensemble_targets = self.angular_views.ensemble_probabilities(
            logits_teacher,
            view_logits,
            self.distill_temperatures,
        )
        # Teacher targets are supervision, not variables for the student loss.
        ensemble_targets = {
            temperature: target.detach()
            for temperature, target in ensemble_targets.items()
        }
        for temperature, target in ensemble_targets.items():
            if target.shape != logits_student.shape:
                raise RuntimeError(
                    f"Angular target at T={temperature} has shape {target.shape}, "
                    f"expected {logits_student.shape}"
                )
            if not torch.isfinite(target).all():
                raise FloatingPointError("Non-finite Angular-KD ensemble target")
            row_sum = target.sum(dim=1)
            if not torch.allclose(row_sum, torch.ones_like(row_sum), atol=1e-5):
                raise RuntimeError("Angular-KD ensemble target is not normalized")

        # Preserve the original CREK hard-sample and hard-class masks. They are
        # computed from the unaugmented frozen teacher, not from the ensemble.
        original_teacher_prob = F.softmax(logits_teacher.detach(), dim=1)
        confidence = original_teacher_prob.max(dim=1)[0].detach()
        confidence_threshold = np.percentile(
            confidence.cpu().numpy().flatten(), 50
        )
        sample_mask = confidence.le(confidence_threshold).bool()

        class_confidence = original_teacher_prob.sum(dim=0).detach()
        class_threshold = np.percentile(
            class_confidence.cpu().numpy().flatten(), 50
        )
        class_mask = class_confidence.le(class_threshold).bool()

        loss_kd = sum(
            self.kd_loss_weight
            * (
                kd_loss_from_probs(
                    logits_student,
                    ensemble_targets[temperature],
                    temperature,
                )
                * sample_mask
            ).mean()
            for temperature in self.distill_temperatures
        )
        loss_cc = sum(
            self.kd_loss_weight
            * (
                cc_loss_from_probs(
                    logits_student,
                    ensemble_targets[temperature],
                    temperature,
                )
                * class_mask
            ).mean()
            for temperature in self.distill_temperatures
        )
        loss_bc = sum(
            self.kd_loss_weight
            * (
                bc_loss_from_probs(
                    logits_student,
                    ensemble_targets[temperature],
                    temperature,
                )
                * sample_mask
            ).mean()
            for temperature in self.distill_temperatures
        )

        student_loss = loss_kd + loss_cc + loss_bc
        loss = student_loss + angular_loss
        if not torch.isfinite(loss):
            raise FloatingPointError("Non-finite CREK + Angular-KD loss")

        self.optim.zero_grad()
        self.angular_optim.zero_grad()
        loss.backward()
        self.optim.step()
        self.angular_optim.step()

        loss_summary = {
            "loss": loss.item(),
            "loss_kd": loss_kd.item(),
            "loss_cc": loss_cc.item(),
            "loss_bc": loss_bc.item(),
            "loss_angular": angular_loss.item(),
        }

        component_values = {
            "loss_kd": loss_kd.item(),
            "loss_cc": loss_cc.item(),
            "loss_bc": loss_bc.item(),
        }
        if self.batch_idx == 0:
            self._epoch_loss_sums = {name: 0.0 for name in component_values}
            self._epoch_loss_count = 0
        for name, value in component_values.items():
            self._epoch_loss_sums[name] += value
        self._epoch_loss_count += 1

        if (self.batch_idx + 1) == self.num_batches:
            os.makedirs(self.cfg.OUTPUT_DIR, exist_ok=True)
            csv_path = osp.join(self.cfg.OUTPUT_DIR, "loss_trends.csv")
            file_mode = "w" if self.epoch == 0 else "a"
            fieldnames = ["epoch", "loss_kd", "loss_cc", "loss_bc"]
            row = {"epoch": self.epoch + 1}
            row.update(
                {
                    name: self._epoch_loss_sums[name] / self._epoch_loss_count
                    for name in component_values
                }
            )
            with open(csv_path, file_mode, newline="") as csv_file:
                writer = csv.DictWriter(
                    csv_file, fieldnames=fieldnames, lineterminator="\n"
                )
                if file_mode == "w":
                    writer.writeheader()
                writer.writerow(row)
            print(
                "Angular epoch summary: "
                f"feature_margin={float(self.angular_views.feature_margin):.4f}, "
                f"logit_margin={float(self.angular_views.logit_margin):.4f}, "
                f"feature_inter={float(angular_components['feature_inter'].detach()):.4f}, "
                f"feature_intra={float(angular_components['feature_intra'].detach()):.4f}, "
                f"logit_inter={float(angular_components['logit_inter'].detach()):.4f}, "
                f"logit_intra={float(angular_components['logit_intra'].detach()):.4f}"
            )
            self.update_lr()

        return loss_summary

    # def parse_batch_train(self, batch):
    #     input = batch["img"]
    #     label = batch["label"]
    #     input = input.to(self.device)
    #     label = label.to(self.device)
    #     return input, label
    
    def parse_batch_train(self, batch_x, batch_u):
        image_weak = batch_x["img"]
        label = batch_x["label"]
        image_strong = batch_u["img"]
        image_weak = image_weak.to(self.device)
        label = label.to(self.device)
        image_strong = image_strong.to(self.device)
        return image_weak, image_strong, label

    def load_model(self, directory, epoch=None):
        if not directory:
            print("Note that load_model() is skipped as no pretrained model is given")
            return

        names = self.get_model_names()

        # By default, the best model is loaded
        model_file = "model-best.pth.tar"

        if epoch is not None:
            model_file = "model.pth.tar-" + str(epoch)

        for name in names:
            model_path = osp.join(directory, name, model_file)

            if not osp.exists(model_path):
                raise FileNotFoundError('Model not found at "{}"'.format(model_path))

            checkpoint = load_checkpoint(model_path)
            state_dict = checkpoint["state_dict"]
            epoch = checkpoint["epoch"]

            # Ignore fixed token vectors only for the prompt model. Angular
            # heads must load strictly from the same last-epoch checkpoint.
            if name == "VLPromptLearner":
                for key in (
                    "prompt_learner.token_prefix",
                    "prompt_learner.token_suffix",
                    "prompt_learner.token_prefix2",
                    "prompt_learner.token_suffix2",
                ):
                    state_dict.pop(key, None)

            print("Loading weights to {} " 'from "{}" (epoch = {})'.format(name, model_path, epoch))
            self._models[name].load_state_dict(
                state_dict, strict=(name == "AngularViews")
            )
            
    @torch.no_grad()
    def test(self, split=None):
        """A generic testing pipeline."""
        self.set_model_mode("eval")
        self.evaluator.reset()


        if split is None:
            split = self.cfg.TEST.SPLIT
            
        if split == "val" and self.val_loader is not None:
            data_loader = self.val_loader
        elif split == "train":
            data_loader = self.train_loader
        else:
            split = "test"  # in case val_loader is None
            data_loader = self.test_loader

        print(f"Evaluate on the *{split}* set")
        
        for batch_idx, batch in enumerate(tqdm(data_loader)):
            image, label = self.parse_batch_test(batch)
            
            # with torch.no_grad():
            #     tea_image_features, tea_text_features, tea_logits = self.model_teacher(image, label)
            
            logit_scale, image_ft, text_features = self.model(image, label)
            
            if self.train_modal == "base2novel":
                if split == "val":
                    output = logit_scale * image_ft @ text_features[:math.ceil(self.n_cls / 2),:].t()
                elif split == "test":
                    output = logit_scale * image_ft @ text_features[math.ceil(self.n_cls / 2):,:].t()
            elif self.train_modal == "cross":
                output = logit_scale * image_ft @ text_features.t()
            
            self.evaluator.process(output, label) 

        results = self.evaluator.evaluate()

        for k, v in results.items():
            tag = f"{split}/{k}"
            self.write_scalar(tag, v, self.epoch)
            
        return list(results.values())[0]
    
    
